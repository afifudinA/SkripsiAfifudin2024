# Verifying Gradle Dependencies
[See here](https://www.spght.dev/articles/23-07-2023/gradle-security)

```sh
$ ./gradlew --write-verification-metadata sha256,pgp clean
```
